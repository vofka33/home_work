TOKEN = '5225178770:AAG8gcca11K1u-gcFZgyqh6Lhky77EvXio0'

keys = {
    'рубль': 'RUR',
    'доллар': 'USD',
    'евро': 'EUR',
    'юань': 'CNY',
    'йена': 'JPY',
    'биткоин': 'BTC'
}