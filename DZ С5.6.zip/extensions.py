import json
import requests
from config import keys

class ConvertionException(Exception):
    pass

class CurrencyConvertor:
    @staticmethod
    def convertor(quote, base, amount):

        if quote == base:
            raise ConvertionException(f'зачем конвертировать {quote} в {base}?')

        try:
            quote_tiker = keys[quote.lower()]
        except KeyError:
            raise ConvertionException(f'неверное название валюты "{quote}".\nДля просмотра перечня доступных валют введите команду /values')

        try:
            base_tiker = keys[base.lower()]
        except KeyError:
            raise ConvertionException(f'неверное название валюты "{base}".\nДля просмотра перечня доступных валют введите команду /values')

        try:
            amount = float(amount)
        except ValueError:
            raise ConvertionException('введено неверное количество, оно должно быть одной цифрой')

        r = requests.get(f'https://min-api.cryptocompare.com/data/price?fsym={quote_tiker}&tsyms={base_tiker}')
        total_base = json.loads(r.content)[keys[base]]*amount
        # total_base = json.loads(r.content)[base_tiker] * amount
        return total_base